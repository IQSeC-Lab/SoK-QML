# QUID-MNIST_4class_ae-noisy.py
# Noisy variant: default.mixed + SPSA, AE latent (8D), MNIST 0/1/2/3, stratified 80/20 split
# Keeps PQC-6 (CRX) setup, QUID/random attacks, optional Q-Detection (Q-WAN) like your noiseless script.

import os, math, random, sys, csv, datetime, copy as _copy
import numpy as np
from dataclasses import dataclass
from typing import Tuple, List

import pennylane as qml
from pennylane import numpy as pnp

import torch
import torch.nn as nn
import torch.optim as torchopt
from torchvision import datasets, transforms

# ---------------------------
# Paths & logging
# ---------------------------
RUN_DIR = "runs"
os.makedirs(RUN_DIR, exist_ok=True)
LOG_CSV = os.path.join(RUN_DIR, "quid_results_mnist4_noisy.csv")

# ---------------------------
# Reproducibility
# ---------------------------
SEED = 7
random.seed(SEED)
np.random.seed(SEED)
pnp.random.seed(SEED)
torch.manual_seed(SEED)

# ---------------------------
# Config
# ---------------------------
@dataclass
class TrainConfig:
    epochs: int = 30
    batch_size: int = 32
    spsa_stepsize: float = 0.01
    spsa_perturb: float = 0.02
    spsa_avg: int = 1
    shots: int = 1000

@dataclass
class EncoderConfig:
    n_qubits: int = 4
    noise_p: float = 0.05
    noisy: bool = True  # noisy in this script

# eps sweep
EPS_LIST = [0.0, 0.1, 0.3, 0.5, 0.7]
REPORT_ASR = True

# ---------------------------
# Data: MNIST(0,1,2,3) -> Conv AE -> 8D latent
# ---------------------------
class ConvAE8(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Conv2d(1, 16, 3, stride=2, padding=1), nn.ReLU(True),
            nn.Conv2d(16, 32, 3, stride=2, padding=1), nn.ReLU(True),
            nn.Flatten(),
            nn.Linear(32*7*7, 128), nn.ReLU(True),
            nn.Linear(128, 8)
        )
        self.decoder = nn.Sequential(
            nn.Linear(8, 128), nn.ReLU(True),
            nn.Linear(128, 32*7*7), nn.ReLU(True),
            nn.Unflatten(1, (32,7,7)),
            nn.ConvTranspose2d(32,16,3,stride=2, padding=1, output_padding=1), nn.ReLU(True),
            nn.ConvTranspose2d(16,1,3,stride=2, padding=1, output_padding=1),
            nn.Sigmoid()
        )
    def forward(self, x):
        z = self.encoder(x)
        xrec = self.decoder(z)
        return xrec, z

def load_mnist4_ae_latent_80_20() -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    tfm = transforms.Compose([transforms.ToTensor()])
    root = "./data"
    ds_tr = datasets.MNIST(root=root, train=True, download=True, transform=tfm)
    ds_te = datasets.MNIST(root=root, train=False, download=True, transform=tfm)

    def filter_4(d):
        X, Y = [], []
        for x, y in d:
            if y in [0,1,2,3]:
                X.append(x.numpy())
                Y.append(y)
        return np.stack(X, axis=0), np.array(Y)

    X1, y1 = filter_4(ds_tr)
    X2, y2 = filter_4(ds_te)
    Xall = np.concatenate([X1, X2], axis=0)  # use full MNIST (train+test)
    yall = np.concatenate([y1, y2], axis=0)

    # Stratified 80/20 per class
    tr_idx, te_idx = [], []
    for c in [0,1,2,3]:
        idx = np.where(yall == c)[0]
        rng = np.random.default_rng(SEED + 100 + c)
        rng.shuffle(idx)
        n_c = len(idx)
        n_tr = int(round(0.8 * n_c))
        tr_idx.extend(idx[:n_tr].tolist())
        te_idx.extend(idx[n_tr:].tolist())
    Xtr_img, ytr = Xall[tr_idx], yall[tr_idx]
    Xte_img, yte = Xall[te_idx], yall[te_idx]

    # Train AE on train split only, then extract 8D latents for both splits
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    ae = ConvAE8().to(device)
    opt = torchopt.Adam(ae.parameters(), lr=1e-3)
    bce = nn.BCELoss()

    Xtr_t = torch.tensor(Xtr_img, dtype=torch.float32).to(device)
    loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(Xtr_t, Xtr_t),
                                         batch_size=128, shuffle=True, drop_last=False)
    ae.train()
    for _ in range(10):
        for xb, yb in loader:
            xr, z = ae(xb)
            loss = bce(xr, yb)
            opt.zero_grad()
            loss.backward()
            opt.step()

    ae.eval()
    with torch.no_grad():
        def to_lat8(Ximg):
            Xt = torch.tensor(Ximg, dtype=torch.float32).to(device)
            _, z = ae(Xt)
            return z.cpu().numpy()
        Xtr_lat8 = to_lat8(Xtr_img)
        Xte_lat8 = to_lat8(Xte_img)

    # Standardize by train stats
    mu = Xtr_lat8.mean(axis=0)
    sigma = Xtr_lat8.std(axis=0) + 1e-8
    Xtr_lat8 = (Xtr_lat8 - mu) / sigma
    Xte_lat8 = (Xte_lat8 - mu) / sigma

    return Xtr_lat8.astype(np.float32), ytr.astype(int), Xte_lat8.astype(np.float32), yte.astype(int)

# ---------------------------
# Devices
# ---------------------------
def make_train_device(n_qubits: int, noisy: bool, shots: int):
    if noisy:
        return qml.device("default.mixed", wires=n_qubits, shots=shots)
    else:
        return qml.device("lightning.qubit", wires=n_qubits, shots=None)

def make_ess_device(n_qubits: int):
    return qml.device("lightning.qubit", wires=n_qubits, shots=None)

# ---------------------------
# Noise after each gate (noisy branch)
# ---------------------------
def amp_depol(noisy: bool, p: float, wires):
    if not noisy:
        return
    ws = wires if isinstance(wires, (list, tuple)) else [wires]
    for w in ws:
        qml.AmplitudeDamping(p, wires=w)
        qml.DepolarizingChannel(p, wires=w)

# ---------------------------
# Angle encoding block (8D -> RZ,RX,RZ,RX per qubit)
# ---------------------------
def _scale_to_pi(x):
    return pnp.pi * pnp.tanh(x)

def angle_encode_once(x8: pnp.ndarray, cfg: EncoderConfig):
    assert len(x8) == 2 * cfg.n_qubits
    x = _scale_to_pi(x8)
    for q in range(cfg.n_qubits):
        a, b = x[2*q], x[2*q + 1]
        qml.RZ(a,   wires=q); amp_depol(cfg.noisy, cfg.noise_p, q)
        qml.RX(b,   wires=q); amp_depol(cfg.noisy, cfg.noise_p, q)
        qml.RZ(a/2, wires=q); amp_depol(cfg.noisy, cfg.noise_p, q)
        qml.RX(b/2, wires=q); amp_depol(cfg.noisy, cfg.noise_p, q)

# ---------------------------
# Sim-2019 Circuit-6 variational layer (CRX all-to-all)
# ---------------------------
def pqc6_layer(theta_L, wires, cfg):
    n = len(wires)
    loc = theta_L["locals"]
    A   = theta_L["crx_matrix"]
    for q in range(n):
        qml.RY(loc[q,0], wires=wires[q]); amp_depol(cfg.noisy, cfg.noise_p, wires[q])
        qml.RZ(loc[q,1], wires=wires[q]); amp_depol(cfg.noisy, cfg.noise_p, wires[q])
        qml.RX(loc[q,2], wires=wires[q]); amp_depol(cfg.noisy, cfg.noise_p, wires[q])
        qml.RZ(loc[q,3], wires=wires[q]); amp_depol(cfg.noisy, cfg.noise_p, wires[q])
    for i in range(n):
        for j in range(i+1, n):
            qml.CRX(A[i,j], wires=[wires[i], wires[j]])
            amp_depol(cfg.noisy, cfg.noise_p, [wires[i], wires[j]])

def build_circuit_pqc6(theta, x8, cfg, n_layers: int = 6):
    wires = list(range(cfg.n_qubits))
    angle_encode_once(x8, cfg)
    for _ in range(n_layers):
        pqc6_layer(theta[_], wires, cfg)

# ---------------------------
# QNodes
# ---------------------------
def make_variational_qnode_noisy(train_dev, cfg: EncoderConfig):
    @qml.qnode(train_dev, interface="auto", diff_method=None)
    def qnode(theta, x8):
        build_circuit_pqc6(theta, x8, cfg, n_layers=6)
        return [qml.expval(qml.PauliZ(w)) for w in range(cfg.n_qubits)]
    return qnode

def make_rho_qnode(ess_dev, cfg: EncoderConfig):
    @qml.qnode(ess_dev, interface=None, diff_method=None)
    def rho_x(x8):
        saved = cfg.noisy
        cfg.noisy = False
        angle_encode_once(x8, cfg)
        cfg.noisy = saved
        return qml.density_matrix(wires=list(range(cfg.n_qubits)))
    return rho_x

# ---------------------------
# Pytree helpers
# ---------------------------
def tree_map(fn, tree):
    if isinstance(tree, (list, tuple)):
        return type(tree)(tree_map(fn, t) for t in tree)
    if isinstance(tree, dict):
        return {k: tree_map(fn, v) for k, v in tree.items()}
    return fn(tree)

def tree_zip_map(fn, a, b):
    if isinstance(a, (list, tuple)):
        return type(a)(tree_zip_map(fn, x, y) for x, y in zip(a, b))
    if isinstance(a, dict):
        return {k: tree_zip_map(fn, a[k], b[k]) for k in a}
    return fn(a, b)

def tree_zeros_like(tree): return tree_map(lambda x: pnp.zeros_like(x), tree)
def tree_random_sign_like(tree): return tree_map(lambda x: pnp.sign(pnp.random.uniform(-1,1,size=x.shape)), tree)
def tree_add_scaled(a, b, scale): return tree_zip_map(lambda x,y: x + scale*y, a, b)

# ---------------------------
# Losses / logits
# ---------------------------
def logits_from_embed(embed: pnp.ndarray, W: pnp.ndarray, b: pnp.ndarray):
    return embed @ W + b

def xent_loss(logits: pnp.ndarray, y: np.ndarray):
    m = logits - pnp.max(logits, axis=1, keepdims=True)
    ex = pnp.exp(m)
    logp = m - pnp.log(pnp.sum(ex, axis=1, keepdims=True))
    n = logits.shape[0]
    return -pnp.mean(logp[pnp.arange(n), y])

def predict(logits):
    return pnp.argmax(logits, axis=1)

# ---------------------------
# Noisy optimizer (SPSA with Adam-style moments)
# ---------------------------
class SPSAWrapper:
    def __init__(self, qnode, cfg: EncoderConfig, tr: TrainConfig):
        self.qnode, self.cfg, self.tr = qnode, cfg, tr
        self.beta1, self.beta2, self.eps = 0.9, 0.999, 1e-8
        self.lr = tr.spsa_stepsize
        self.m = None
        self.v = None
        self.t = 0

    def _adam_update(self, params, grads):
        if self.m is None:
            self.m = tree_zeros_like(params)
            self.v = tree_zeros_like(params)
            self.t = 0
        self.t += 1
        self.m = tree_zip_map(lambda m, g: self.beta1*m + (1-self.beta1)*g, self.m, grads)
        self.v = tree_zip_map(lambda v, g: self.beta2*v + (1-self.beta2)*(g*g), self.v, grads)
        mhat = tree_map(lambda m: m / (1 - self.beta1**self.t), self.m)
        vhat = tree_map(lambda v: v / (1 - self.beta2**self.t), self.v)  # FIXED: beta2
        step = tree_zip_map(lambda m, v: self.lr * m / (pnp.sqrt(v) + self.eps), mhat, vhat)
        return tree_zip_map(lambda p, s: p - s, params, step)

    def _eval_loss(self, th, Wh, bh, Xb, yb):
        E = pnp.stack([self.qnode(th, Xb[i]) for i in range(len(yb))], axis=0)
        return xent_loss(logits_from_embed(E, Wh, bh), yb)

    def _eval_loss_weighted(self, th, Wh, bh, Xb, yb, weights_np):
        E = pnp.stack([self.qnode(th, Xb[i]) for i in range(len(yb))], axis=0)
        lg = logits_from_embed(E, Wh, bh)
        m = lg - pnp.max(lg, axis=1, keepdims=True)
        ex = pnp.exp(m); logp = m - pnp.log(pnp.sum(ex, axis=1, keepdims=True))
        per = -logp[pnp.arange(len(yb)), yb]
        w = pnp.array(weights_np).flatten() + 1e-12
        return pnp.sum(w * per) / pnp.sum(w)

    def step(self, params, Xb, yb):
        theta, W, b = params
        c = self.tr.spsa_perturb
        grads = []
        obj = 0.0
        for _ in range(self.tr.spsa_avg):
            S_theta = tree_random_sign_like(theta)
            S_W     = pnp.sign(pnp.random.uniform(-1, 1, size=W.shape))
            S_b     = pnp.sign(pnp.random.uniform(-1, 1, size=b.shape))
            theta_p = tree_add_scaled(theta, S_theta, +c)
            theta_m = tree_add_scaled(theta, S_theta, -c)
            W_p, W_m = W + c*S_W, W - c*S_W
            b_p, b_m = b + c*S_b, b - c*S_b
            lp = self._eval_loss(theta_p, W_p, b_p, Xb, yb)
            lm = self._eval_loss(theta_m, W_m, b_m, Xb, yb)
            scale = (lp - lm) / (2 * c)
            g_theta = tree_map(lambda s: scale * s, S_theta)
            g_W     = scale * S_W
            g_b     = scale * S_b
            if not grads:
                grads = [g_theta, g_W, g_b]
            else:
                grads[0] = tree_zip_map(lambda a,b_: a + b_, grads[0], g_theta)
                grads[1] = grads[1] + g_W
                grads[2] = grads[2] + g_b
            obj += 0.5 * (lp + lm)
        grads[0] = tree_map(lambda x: x / self.tr.spsa_avg, grads[0])
        grads[1] = grads[1] / self.tr.spsa_avg
        grads[2] = grads[2] / self.tr.spsa_avg
        new_params = self._adam_update([theta, W, b], grads)
        return new_params, float(obj / self.tr.spsa_avg)

    def step_weighted(self, params, Xb, yb, weights_np):
        theta, W, b = params
        c = self.tr.spsa_perturb
        grads = []
        obj = 0.0
        for _ in range(self.tr.spsa_avg):
            S_theta = tree_random_sign_like(theta)
            S_W     = pnp.sign(pnp.random.uniform(-1, 1, size=W.shape))
            S_b     = pnp.sign(pnp.random.uniform(-1, 1, size=b.shape))
            theta_p = tree_add_scaled(theta, S_theta, +c)
            theta_m = tree_add_scaled(theta, S_theta, -c)
            W_p, W_m = W + c*S_W, W - c*S_W
            b_p, b_m = b + c*S_b, b - c*S_b
            lp = self._eval_loss_weighted(theta_p, W_p, b_p, Xb, yb, weights_np)
            lm = self._eval_loss_weighted(theta_m, W_m, b_m, Xb, yb, weights_np)
            scale = (lp - lm) / (2 * c)
            g_theta = tree_map(lambda s: scale * s, S_theta)
            g_W     = scale * S_W
            g_b     = scale * S_b
            if not grads:
                grads = [g_theta, g_W, g_b]
            else:
                grads[0] = tree_zip_map(lambda a,b_: a + b_, grads[0], g_theta)
                grads[1] = grads[1] + g_W
                grads[2] = grads[2] + g_b
            obj += 0.5 * (lp + lm)
        grads[0] = tree_map(lambda x: x / self.tr.spsa_avg, grads[0])
        grads[1] = grads[1] / self.tr.spsa_avg
        grads[2] = grads[2] / self.tr.spsa_avg
        new_params = self._adam_update([theta, W, b], grads)
        return new_params, float(obj / self.tr.spsa_avg)

# ---------------------------
# Minibatches
# ---------------------------
def make_minibatches(X, y, bs, shuffle=True):
    idx = np.arange(len(y))
    if shuffle:
        np.random.default_rng(SEED+123).shuffle(idx)
    for s in range(0, len(y), bs):
        j = idx[s:s+bs]
        yield X[j], y[j], j  # also yield batch indices into the global training set

# ---------------------------
# QUID: ESS (Frobenius) label flipping
# ---------------------------
def frob(A, B):
    D = A - B
    return pnp.sqrt(pnp.sum(pnp.real(D * pnp.conj(D))))

def class_prototypes(rhos: List[pnp.ndarray], ys: np.ndarray, n_classes=4):
    protos = []
    for c in range(n_classes):
        idx = np.where(ys==c)[0]
        mats = [rhos[i] for i in idx]
        protos.append(pnp.mean(pnp.stack(mats, axis=0), axis=0))
    return protos

def make_rho_encoder(ess_dev, cfg: EncoderConfig):
    @qml.qnode(ess_dev, interface=None, diff_method=None)
    def rho_x(x8):
        saved = cfg.noisy
        cfg.noisy = False
        angle_encode_once(x8, cfg)
        cfg.noisy = saved
        return qml.density_matrix(wires=list(range(cfg.n_qubits)))
    return rho_x

def quid_label_flip(Xtr8, ytr, rho_x_fun, epsilon: float, seed=SEED):
    if epsilon <= 0.0:
        return ytr.copy(), np.array([], dtype=int), None
    rng = np.random.default_rng(seed)
    n = len(ytr)
    k = int(round(epsilon * n))
    all_idx = np.arange(n)
    poisoned_idx = rng.choice(all_idx, size=k, replace=False)
    clean_idx = np.setdiff1d(all_idx, poisoned_idx)
    rhos_clean = [pnp.array(rho_x_fun(Xtr8[i])) for i in clean_idx]
    protos = class_prototypes(rhos_clean, ytr[clean_idx], n_classes=4)
    y_poison = ytr.copy()
    for i in poisoned_idx:
        rho_i = pnp.array(rho_x_fun(Xtr8[i]))
        dists = [frob(rho_i, protos[c]) for c in range(4)]
        tgt = int(pnp.argmax(pnp.stack(dists)))
        y_poison[i] = tgt
    return y_poison, poisoned_idx, protos

# ---------------------------
# Inference & metrics
# ---------------------------
def infer(params, qnode, X):
    theta, W, b = params
    E = pnp.stack([qnode(theta, X[i]) for i in range(len(X))], axis=0)
    logits = logits_from_embed(E, W, b)
    preds  = predict(logits)
    return np.array(preds), np.array(logits, dtype=float)

def accuracy(yhat, y):
    return 100.0 * (yhat == y).mean()

def _append_csv(row_dict: dict, path: str = LOG_CSV):
    file_exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(row_dict.keys()))
        if not file_exists:
            writer.writeheader()
        writer.writerow(row_dict)
        f.flush()

# ============================================================
# Q-DETECTION — Q-WAN (Ising) persistent bank (optional)
# ============================================================
class QWANIsingBank:
    def __init__(self,
                 n_spins_total: int,
                 eta: float = 0.05,
                 alpha: float = 1.0,
                 beta_start: float = 0.1,
                 beta_end: float = 2.0,
                 sa_sweeps: int = 50,
                 seed: int = SEED):
        self.N = n_spins_total
        self.eta = eta
        self.alpha = alpha
        self.beta_start = beta_start
        self.beta_end = beta_end
        self.sa_sweeps = sa_sweeps
        self.rng = np.random.default_rng(seed)
        self.h = np.zeros((self.N,), dtype=np.float64)
        self.J = np.zeros((self.N, self.N), dtype=np.float64)  # symmetric, zero diag

    def _beta_schedule(self, steps=30):
        return np.linspace(self.beta_start, self.beta_end, steps)

    def _sa_sample_subgraph(self, idx, h_sub, J_sub, beta_schedule, init=None):
        B = len(idx)
        s = init.copy() if init is not None else self.rng.choice([-1, 1], size=B)
        samples = []
        for k, beta in enumerate(beta_schedule):
            for _ in range(self.sa_sweeps):
                i = self.rng.integers(0, B)
                new_si = -s[i]
                delta = new_si - s[i]
                dE = -(h_sub[i]*delta + np.dot(J_sub[i], s)*delta)
                if dE <= 0 or self.rng.random() < math.exp(-beta * dE):
                    s[i] = new_si
            if k >= int(0.7 * len(beta_schedule)):
                samples.append(s.copy())
        return s, samples

    def _expectations(self, samples):
        if len(samples) == 0:
            return None, None
        X = np.stack(samples, axis=0)
        m = X.mean(axis=0)
        C = (X.T @ X) / X.shape[0]
        return m, C

    def train_step(self, idx_batch: np.ndarray, per_sample_losses_batch: np.ndarray):
        idx = np.asarray(idx_batch, dtype=int)
        L = np.asarray(per_sample_losses_batch, dtype=np.float64)
        Ln = (L - L.mean()) / (L.std() + 1e-8)

        h_sub = self.h[idx].copy()
        J_sub = self.J[np.ix_(idx, idx)].copy()
        np.fill_diagonal(J_sub, 0.0)

        betas = self._beta_schedule(steps=30)

        _, free_samples = self._sa_sample_subgraph(idx, h_sub, J_sub, betas, init=None)
        m_free, C_free = self._expectations(free_samples)
        if m_free is None:
            m_free = np.zeros_like(h_sub)
            C_free = np.zeros_like(J_sub)

        h_eff = h_sub - 0.5 * self.alpha * Ln
        _, guided_samples = self._sa_sample_subgraph(idx, h_eff, J_sub, betas, init=None)
        m_guided, C_guided = self._expectations(guided_samples)
        if m_guided is None:
            m_guided = np.zeros_like(h_sub)
            C_guided = np.zeros_like(J_sub)

        dC = 0.5 * ((C_guided - C_free) + (C_guided - C_free).T)
        dm = m_guided - m_free
        np.fill_diagonal(dC, 0.0)

        J_sub_new = J_sub - self.eta * dC
        h_sub_new = h_sub - self.eta * dm

        self.h[idx] = h_sub_new
        self.J[np.ix_(idx, idx)] = J_sub_new
        self.J = 0.5 * (self.J + self.J.T)
        np.fill_diagonal(self.J, 0.0)

    def weights(self, idx_batch: np.ndarray, per_sample_losses_batch: np.ndarray):
        idx = np.asarray(idx_batch, dtype=int)
        L = np.asarray(per_sample_losses_batch, dtype=np.float64)
        Ln = (L - L.mean()) / (L.std() + 1e-8)

        h_sub = self.h[idx].copy()
        J_sub = self.J[np.ix_(idx, idx)].copy()
        np.fill_diagonal(J_sub, 0.0)

        betas = self._beta_schedule(steps=30)
        h_eff = h_sub - 0.5 * self.alpha * Ln
        _, guided_samples = self._sa_sample_subgraph(idx, h_eff, J_sub, betas, init=None)
        if len(guided_samples) == 0:
            s = np.sign(h_eff + 1e-6)
            v = (s + 1.0) / 2.0
            return np.clip(v, 0.0, 1.0)

        m_guided, _ = self._expectations(guided_samples)
        v = (m_guided + 1.0) / 2.0
        return np.clip(v, 0.0, 1.0)

# ---------------------------
# Q-Detection helpers
# ---------------------------
def compute_per_sample_losses(qnode, params, Xb, yb):
    theta, W, b = params
    E = pnp.stack([qnode(theta, Xb[i]) for i in range(len(yb))], axis=0)
    logits = logits_from_embed(E, W, b)
    m = logits - pnp.max(logits, axis=1, keepdims=True)
    ex = pnp.exp(m); logp = m - pnp.log(pnp.sum(ex, axis=1, keepdims=True))
    per = -logp[pnp.arange(len(yb)), yb]
    return np.asarray(per)

def weighted_loss_mean(qnode, params, Xb, yb, weights_np):
    theta, W, b = params
    E = pnp.stack([qnode(theta, Xb[i]) for i in range(len(yb))], axis=0)
    logits = logits_from_embed(E, W, b)
    m = logits - pnp.max(logits, axis=1, keepdims=True)
    ex = pnp.exp(m); logp = m - pnp.log(pnp.sum(ex, axis=1, keepdims=True))
    per = -logp[pnp.arange(len(yb)), yb]
    w = pnp.array(weights_np).flatten() + 1e-12
    return pnp.sum(w * per) / pnp.sum(w)

# ---------------------------
# Runner (PQC-6) with/without Q-Detection
# ---------------------------
def init_params_pqc6(n_qubits: int, n_layers: int = 6, n_classes: int = 4):
    theta = []
    for _ in range(n_layers):
        locals_ = pnp.random.uniform(-0.1, 0.1, size=(n_qubits, 4))
        M = pnp.zeros((n_qubits, n_qubits))
        for i in range(n_qubits):
            for j in range(i+1, n_qubits):
                M[i, j] = np.random.uniform(-0.1, 0.1)
        theta.append({"locals": locals_, "crx_matrix": M})
    W = pnp.random.uniform(-0.1, 0.1, size=(n_qubits, n_classes))
    b = pnp.zeros((n_classes,))
    return theta, W, b

def train_epoch_noisy_qd(params, Xtr8, ytr, qnode, tr: TrainConfig, qwan_bank: QWANIsingBank, spsa: SPSAWrapper):
    theta, W, b = params
    for Xb, yb, idxb in make_minibatches(Xtr8, ytr, tr.batch_size, shuffle=True):
        per_losses = compute_per_sample_losses(qnode, [theta, W, b], Xb, yb)
        for _ in range(2):
            qwan_bank.train_step(idxb, per_losses)
        v = qwan_bank.weights(idxb, per_losses)
        [theta, W, b], _ = spsa.step_weighted([theta, W, b], Xb, yb, v)
    return [theta, W, b]

def train_epoch_noisy(params, Xtr8, ytr, qnode, tr: TrainConfig, spsa: SPSAWrapper):
    theta, W, b = params
    for Xb, yb, _ in make_minibatches(Xtr8, ytr, tr.batch_size, shuffle=True):
        [theta, W, b], _ = spsa.step([theta, W, b], Xb, yb)
    return [theta, W, b]

def run_one_setting_pqc6(eps_list=EPS_LIST):
    print("\n==============================================")
    print("PQC6 | n=4 | encoding=RZ-RX-RZ-RX | noise=(damp=0.05,depol=0.05)")
    print("==============================================")

    # 80/20 AE split on full MNIST (0,1,2,3)
    Xtr8, ytr, Xte8, yte = load_mnist4_ae_latent_80_20()

    cfg = EncoderConfig(n_qubits=4, noise_p=0.05, noisy=True)
    tr  = TrainConfig(epochs=30, batch_size=32, spsa_stepsize=0.01, spsa_perturb=0.02, spsa_avg=1, shots=1000)

    train_dev = make_train_device(cfg.n_qubits, noisy=cfg.noisy, shots=tr.shots)
    qnode = make_variational_qnode_noisy(train_dev, cfg)

    ess_dev = make_ess_device(cfg.n_qubits)
    rho_x   = make_rho_qnode(ess_dev, cfg)

    theta0, W0, b0 = init_params_pqc6(cfg.n_qubits, n_layers=6, n_classes=4)

    for eps in eps_list:
        for attack_type in ["quid", "random"]:
            if attack_type == "quid":
                ytr_poison, poisoned_idx, _ = quid_label_flip(Xtr8, ytr, rho_x, epsilon=eps, seed=SEED)
            else:
                # random baseline with same epsilon
                rng = np.random.default_rng(SEED + 999)
                ytr_poison = ytr.copy()
                if eps > 0.0:
                    k = int(round(eps * len(ytr_poison)))
                    idxs = rng.choice(np.arange(len(ytr_poison)), size=k, replace=False)
                    for i in idxs:
                        choices = [c for c in range(4) if c != int(ytr_poison[i])]
                        ytr_poison[i] = int(rng.choice(choices))
                poisoned_idx = np.array([], dtype=int) if eps <= 0.0 else idxs

            for use_qdetect in [False, True]:
                theta = _copy.deepcopy(theta0); W = pnp.array(W0); b = pnp.array(b0)
                params = [theta, W, b]
                defense_name = "q-detection" if use_qdetect else "none"
                print(f"\n[attack={attack_type}] eps={eps} | defense={defense_name} | poisoned={len(poisoned_idx)}")

                spsa = SPSAWrapper(qnode, cfg, tr)
                if use_qdetect:
                    qwan_bank = QWANIsingBank(n_spins_total=len(ytr_poison), eta=0.05, alpha=1.0)
                    for _ in range(tr.epochs):
                        params = train_epoch_noisy_qd(params, Xtr8, ytr_poison, qnode, tr, qwan_bank, spsa)
                else:
                    for _ in range(tr.epochs):
                        params = train_epoch_noisy(params, Xtr8, ytr_poison, qnode, tr, spsa)

                # Evaluate on held-out 20%
                yhat, _ = infer(params, qnode, Xte8)
                acc = accuracy(yhat, yte)

                # ASR on poisoned training points
                if REPORT_ASR and len(poisoned_idx) > 0:
                    yhat_tr, _ = infer(params, qnode, Xtr8[poisoned_idx])
                    asr = 100.0 * np.mean(yhat_tr == ytr_poison[poisoned_idx])
                else:
                    asr = 0.0 if eps == 0.0 else float("nan")

                print(f"[{attack_type} eps={eps} | {defense_name}] Test Acc = {acc:6.2f}% | ASR = {asr:6.2f}%")

                _append_csv({
                    "timestamp": datetime.datetime.now().isoformat(timespec="seconds"),
                    "which_pqc": "pqc6",
                    "attack_type": attack_type,
                    "defense": defense_name,
                    "noisy": True,
                    "n_qubits": cfg.n_qubits,
                    "shots": tr.shots,
                    "epochs": tr.epochs,
                    "batch_size": tr.batch_size,
                    "epsilon": float(eps),
                    "poisoned_count": int(len(poisoned_idx)),
                    "test_acc_pct": float(f"{acc:.4f}"),
                    "asr_pct": float(f"{asr:.4f}") if REPORT_ASR else float("nan"),
                    "seed": int(SEED),
                })

def main():
    run_one_setting_pqc6(eps_list=EPS_LIST)

if __name__ == "__main__":
    main()
